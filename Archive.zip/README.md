# Name
Horiseon Marketing Company Website

### Live Application Link 👀
Horiseon Marketing Company Website: [See deployment on Github Pages](https://adamromano89.github.io/Horiseon-Marketing-Code-Refactor/)

### Live Application Link 👀
Horiseon Marketing Company Website: [http://adamromano.net/]
### Built With 🧰
- HTML 
- CSS

# Work Completed
Refactoring the website code by adding the following:

- [x]Semantic HTML elements
- [x]Making the elements follow a logical structure independent styling and positioning
- [x]Adding alt attributes
- [x]Heading attributes fall in sequential order
- [x]adding a descriptive title

# Project Visual :sunglasses:
! [Project-Picture] (https://github.com/AdamRomano89/Horiseon-Marketing-Code-Refactor/blob/53c8e075c41089c1e7e1910be5e01e5098554112/Images/Mockup.png)

## Authors, Acknowledgement, & Resources 🤝

### Teaching Crew at UCB Coding Bootcamp 🎉
[Bootcamp Program](https://techbootcamps.utexas.edu/coding/)

### W3Schools 🤓
[W3Schools HTML & CSS Resources](https://www.w3schools.com/)